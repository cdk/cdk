package com;

public class Test123
{
    public @Override void finalize() throws Throwable
    {
        super.finalize();
    }
}
