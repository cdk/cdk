/**
 * Test class with class Javadoc comment but no methods.
 * Will we get a divide by zero exception somewhere?
 */
public class Test69
{
}
