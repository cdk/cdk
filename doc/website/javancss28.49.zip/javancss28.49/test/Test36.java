public class Test36 {
}//