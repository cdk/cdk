public class Test35 {
  }