public class Test70 extends Test70Super
{
    public class InnerClass
    {
        public void test()
        {
            int b = Test70.super.a;
        }
    }
}
