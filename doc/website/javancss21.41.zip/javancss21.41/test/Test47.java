import foo.bar;

/**
 * Hello
 */
public interface Test47 {
    /** bla */
    public void filter();
}
