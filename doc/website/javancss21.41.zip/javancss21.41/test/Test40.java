public class Test40 {
	int i = 0;

	/** CCN = 3 */
	public Test40(int j) {
		if (j > 0) {
			return;
		}
		i = j;
	}
}
