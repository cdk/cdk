/*
 *  Copyright (C) 2000  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import java.io.*;
import java.util.*;
import org.netbeans.lib.cvsclient.*;
import org.netbeans.lib.cvsclient.connection.*;
import org.netbeans.lib.cvsclient.admin.*;
import org.netbeans.lib.cvsclient.command.*;
import org.netbeans.lib.cvsclient.command.add.*;
import org.netbeans.lib.cvsclient.command.remove.*;
import org.netbeans.lib.cvsclient.event.*;
import org.netbeans.lib.cvsclient.commandLine.*;

/**
 *  Facilitates operations regarding CVS. The file manipulation
 *  required by Ack has consequences when the tests are under CVS
 *  control. When files or directories are added or removed, CVS must
 *  be notified. This class localizes the code needed to work with
 *  CVS.
 */
public class CvsUtilities {

	/**
	 *  Returns whether the given directory is under CVS control. If
	 *  the directory contains a CVS control file, it is considered
	 *  under CVS control. If the given file is not a directory, the
	 *  parent of the file is attempted; however, this is only
	 *  possible if the parent of the file is correctly resolved (the
	 *  getParentFile() cannot be null).
	 *
	 *  @param dir the directory in quesiton
	 *
	 *  @return
	 */
	public static boolean isCvsControlled(File dir) {
		return (getCvsDirectory(dir) != null);
	}

	/**
	 *  Returns CVS control directory in the given directory.  If the
	 *  given file is not a directory, the parent of the file is
	 *  attempted; however, this is only possible if the parent of the
	 *  file is correctly resolved (the getParentFile() cannot be
	 *  null).
	 *
	 *  @param parent the directory under CVS control
	 *
	 *  @return
	 */
	public static File getCvsDirectory(File parent) {

		if (!parent.exists()) {
			return null;
		}

		if (!parent.isDirectory() && (parent.getParentFile() != null)) {
			parent = parent.getParentFile();
		}

		File[] files = parent.listFiles();

		if (files == null) {
			return null;
		}

		for (int i = 0; i < files.length; ++i) {
			if (isCvsFile(files[i])) {
				return files[i];
			}
		}

		return null;
	}

	/**
	 *  Returns whether the given file is a CVS control file. These
	 *  files should not be deleted without notifying CVS.
	 *
	 *  @param file the file in quesiton
	 *
	 *  @return
	 */
	public static boolean isCvsFile(File file) {
		return (file.isDirectory() && file.getName().equals("CVS"));
	}

	/**
	 *  Remove a file from CVS.
	 *
	 *  @param file  the file to remove
	 *
	 *  @throws CommandException
	 *  @throws IOException
	 */
	public static void removeFile(File file)
			throws CommandException, IOException {

		if (file.exists()) {
			throw new CommandException("file '" + file.getName()
									   + "' still exists");
		}

		File cvsDir = getCvsDirectory(file.getParentFile());
		GlobalOptions options = new GlobalOptions();

		options.setCVSRoot(getCvsRoot(cvsDir));

		Client client = getClient(cvsDir);
		RemoveCommand remove = new RemoveCommand();

		remove.setFiles(new File[]{ file });
		client.executeCommand(remove, options);
		client.getConnection().close();
	}

	/**
	 *  Add a file to CVS.
	 *
	 *  @param file  the file to add
	 *
	 *  @throws CommandException
	 *  @throws IOException
	 */
	public static void addFile(File file)
			throws CommandException, IOException {

		if (!file.exists()) {
			throw new CommandException("file '" + file.getName()
									   + "' does not exist");
		}

		File cvsDir = getCvsDirectory(file.getParentFile());
		GlobalOptions options = new GlobalOptions();

		options.setCVSRoot(getCvsRoot(cvsDir));

		Client client = getClient(cvsDir);
		AddCommand add = new AddCommand();

		add.setFiles(new File[]{ file });
		client.executeCommand(add, options);
		client.getConnection().close();
	}

	/**
	 *  Returns the files in <code>dir</code> known to CVS.
	 *
	 *  @param dir
	 *
	 *  @return
	 *
	 *  @throws IOException
	 */
	public static File[] getFiles(File dir) throws IOException {

		File cvsDir = getCvsDirectory(dir);
		GlobalOptions options = new GlobalOptions();

		options.setCVSRoot(getCvsRoot(cvsDir));

		Client client = getClient(cvsDir);
		Set files = client.getAllFiles(dir);

		client.getConnection().close();

		return (File[]) files.toArray(new File[files.size()]);
	}

	/**
	 *  Create and return a client connected to CVS.
	 *
	 *  @param cvsDir the CVS directory for repository information
	 *
	 *  @return
	 *
	 *  @throws IOException
	 */
	static Client getClient(File cvsDir) throws IOException {

		try {
			String cvsRoot = getCvsRoot(cvsDir);
			ServerConnection connection = new ServerConnection();

			connection.setRepository(cvsRoot);
			connection.open();

			StandardAdminHandler admin = new StandardAdminHandler();
			Client client = new Client(connection, admin);

			client.setLocalPath(cvsDir.getParent());

			return client;
		} catch (AuthenticationException ex) {
			throw new IOException(ex.getMessage());
		}
	}

	/**
	 *  Returns the value of CVS root from the CVS directory.
	 *
	 *  @param cvsDir
	 *
	 *  @return
	 *
	 *  @throws IOException
	 */
	static String getCvsRoot(File cvsDir) throws IOException {

		File cvsRootFile = new File(cvsDir, "Root");
		BufferedReader input =
			new BufferedReader(new FileReader(cvsRootFile));
		String cvsRoot = input.readLine();

		input.close();

		return cvsRoot;
	}
}
