/*
 *  Copyright (C) 2000  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import java.io.*;
import java.util.*;
import org.apache.tools.ant.PathTokenizer;

/**
 *  Class FileUtilities
 *
 *
 *  @author Bradley A. Smith (yeldar@home.com)
 */
public class FileUtilities {

	/**
	 *  Whether the native library has been loaded. Used to delay
	 *  library loading in case it is not needed.
	 */
	public static boolean nativeLibraryLoaded = false;

	/**
	 *  Returns a set of the files in the current directory.
	 *
	 *  @return
	 */
	public static Set getFileSet() {
		return getFileSet(new File("."));
	}

	/**
	 *  Returns a set of the files in the given directory.
	 *
	 *  @param dir
	 *
	 *  @return
	 */
	public static Set getFileSet(File dir) {

		Set fileSet = new HashSet();
		File[] currentFiles = dir.listFiles();

		for (int i = 0; i < currentFiles.length; ++i) {
			fileSet.add(currentFiles[i]);
		}

		return fileSet;
	}

	/**
	 *  Changes working directory.
	 *
	 *
	 *  @param path
	 *  @throws FileNotFoundException if the directory does not exist.
	 *  @throws IOException if failed to lookup canonical form of path.
	 */
	public static void chdir(String path)
			throws FileNotFoundException, IOException {

		if (!nativeLibraryLoaded) {
			String osName = System.getProperty("os.name");
			
			if (osName.equals("Windows NT")) {
				osName = "Win32";
			}
			
			System.loadLibrary("FileUtilities_" + osName);
			nativeLibraryLoaded = true;
		}


		File dir = new File(path);

		if (!dir.exists()) {
			throw new FileNotFoundException("directory does not exist");
		}

		if (!dir.isDirectory()) {
			throw new FileNotFoundException(dir + " is not a directory");
		}

		String libraryPath =
			resolveToAbsolutePaths(System.getProperty("java.library.path"));

		System.getProperties().put("java.library.path", libraryPath);

		String classPath =
			resolveToAbsolutePaths(System.getProperty("java.class.path"));

		System.getProperties().put("java.class.path", classPath);

		String canonPath = (new File(path)).getCanonicalPath();

		System.getProperties().put("user.dir", canonPath);
		nativeChdir(canonPath);
	}

	/**
	 *  Method resolveToAbsolutePaths
	 *
	 *
	 *  @param path
	 *
	 *  @return
	 */
	public static String resolveToAbsolutePaths(String path) {

		StringBuffer newPath = new StringBuffer();
		PathTokenizer tokenizer = new PathTokenizer(path);

		while (tokenizer.hasMoreTokens()) {
			File f1 = new File(tokenizer.nextToken());

			newPath.append(f1.getAbsolutePath());
			newPath.append(File.pathSeparatorChar);
		}

		return newPath.toString();
	}

	/**
	 *  Method copyFile
	 *
	 *
	 *  @param in
	 *  @param out
	 *
	 *  @throws IOException
	 */
	public static void copyFile(File in, File out) throws IOException {

		FileInputStream fis = new FileInputStream(in);

		if (out.exists()) {
			throw new IOException("destination file '" + out + "' exists");
		}

		FileOutputStream fos = new FileOutputStream(out);
		byte[] buf = new byte[1024];
		int i = fis.read(buf);

		while (i != -1) {
			fos.write(buf, 0, i);

			i = fis.read(buf);
		}

		fis.close();
		fos.close();
	}

	/**
	 *  Method compareFiles
	 *
	 *
	 *  @param expected
	 *  @param file
	 *
	 *  @return
	 *
	 *  @throws IOException
	 */
	public static boolean compareFiles(File expected, File file)
			throws IOException {

		boolean result = true;
		FileInputStream fis = new FileInputStream(expected);
		FileInputStream fis2 = new FileInputStream(file);
		byte[] buf = new byte[1024];
		byte[] buf2 = new byte[1024];
		int i;
		int i2;

		do {
			i = fis.read(buf);
			i2 = fis2.read(buf2);

			if (i != i2) {
				result = false;

				break;
			}

			for (int j = 0; j < i; ++j) {
				if (buf[j] != buf2[j]) {
					result = false;

					break;
				}
			}
		} while (result && (i != -1) && (i2 != -1));

		fis.close();
		fis2.close();

		return result;
	}

	/**
	 *  Deletes all the target files. If recursive, subdirectories are
	 *  also deleted, else subdirectories are ignored.
	 *
	 *  @param targets the files to delete.
	 *  @param recursive if true recursively delete subdirectories.
	 *  @return true if all deletions successful, otherwise false.
	 */
	public static boolean deleteAll(File[] targets, boolean recursive) {

		boolean result;
		boolean success = true;

		for (int j = 0; j < targets.length; ++j) {
			if (targets[j].isDirectory() && recursive) {
				result = deleteAll(targets[j]);
			} else {
				result = targets[j].delete();
			}

			if (!result) {
				success = false;
			}
		}

		return success;
	}

	/**
	 *  Deletes the target file or directory. If a directory, all contents and
	 *  subdirectories are also deleted.
	 *
	 *  @param target the file or directory to delete.
	 *  @return true if all deletions successful, otherwise false.
	 */
	public static boolean deleteAll(File target) {

		boolean result;
		boolean success = true;

		if (target.isDirectory()) {
			File[] contents = target.listFiles();

			while (success && contents != null && contents.length != 0) {
				for (int i = 0; i < contents.length; ++i) {
					result = deleteAll(contents[i]);

					if (!result) {
						success = false;
					}
				}

				contents = target.listFiles();
			}

			result = target.delete();
		} else {
			result = target.delete();
		}

		if (!result) {
			success = false;
		}

		return success;
	}

	/**
	 *  Method copyStreamToFile
	 *
	 *
	 *  @param in
	 *  @param out
	 *
	 *  @throws IOException
	 */
	public static void copyStreamToFile(InputStream in, File out)
			throws IOException {

		OutputStream fileOutput = new FileOutputStream(out);

		try {
			byte[] buffer = new byte[1024];
			int len = in.read(buffer);

			while (len > 0) {
				fileOutput.write(buffer, 0, len);

				len = in.read(buffer);
			}
		} finally {
			fileOutput.close();
		}
	}

	/**
	 *  Changes working directory.
	 *
	 *  @param path
	 */
	private static native void nativeChdir(String path);
}
