/*
 *  Copyright (C) 2000  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import junit.framework.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Tests for the ZipUtilities class.
 */
public class TestZipUtilities extends junit.framework.TestCase {

	/**
	 *  Test zip file.
	 */
	File testZip;

	/**
	 *  Test directory for isolating testing operations.
	 */
	File testDirectory;

	/**
	 *  Method main
	 *
	 *
	 *  @param args
	 */
	public static void main(String[] args) {
		junit.textui.TestRunner.run(suite());
	}

	/**
	 * Create a test case with given name.
	 *
	 * @param name this test case's name.
	 */
	public TestZipUtilities(String name) {
		super(name);
	}

	/**
	 * Setup fixtures.
	 */
	public void setUp() {

		setUpTestDirectory();

		testZip = new File("test.zip");

		try {
			FileUtilities
				.copyStreamToFile(getClass()
					.getResourceAsStream("TestZipUtilities.zip"), testZip);
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Method setUpTestDirectory
	 *
	 */
	void setUpTestDirectory() {

		try {
			testDirectory = new File(".", "TestZipUtilities.directory");

			assert("Set up error: TestZipUtilities.directory exists",
				   !testDirectory.exists());
			testDirectory.mkdir();
			FileUtilities.chdir("TestZipUtilities.directory");
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Method tearDown
	 *
	 */
	public void tearDown() {

		try {
			FileUtilities.chdir("..");
			assert(FileUtilities.deleteAll(testDirectory));
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 * Returns suite of tests contained in this test case.
	 *
	 *  @return all tests in this test case
	 */
	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(TestZipUtilities.class);
	}

	/**
	 * Test copying file from zip.
	 */
	public void testCopyOut() {

		try {
			ZipInputStream zis =
				new ZipInputStream(new FileInputStream(testZip));

			while (ZipUtilities.copyFileFromZip(zis, new File("."))) {

				// continue
			}

			zis.close();
		} catch (IOException ex) {
			fail(ex.toString());
		}

		File expectedFile = new File("test/test.file");

		assert(expectedFile.exists());

		try {
			BufferedReader br =
				new BufferedReader(new FileReader(expectedFile));

			assertEquals("Test file", br.readLine());
			assertEquals(null, br.readLine());
			br.close();
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 * Test copying file into zip.
	 */
	public void testCopyIn() {

		// Extract test.zip
		try {
			ZipInputStream zis =
				new ZipInputStream(new FileInputStream(testZip));

			while (ZipUtilities.copyFileFromZip(zis, new File("."))) {

				// continue
			}

			zis.close();
		} catch (IOException ex) {
			fail(ex.toString());
		}

		// Recreate test.zip as test2.zip
		try {
			ZipOutputStream zos =
				new ZipOutputStream(new FileOutputStream("test2.zip"));

			ZipUtilities.copyFileIntoZip(zos, new File("test/test.file"));
			zos.close();
		} catch (IOException ex) {
			fail(ex.toString());
		}

		File expectedFile = new File("test2.zip");

		assert(expectedFile.exists());

		try {
			String[] list = ZipUtilities.list(expectedFile);

			assertEquals(1, list.length);
			assertEquals("test" + File.separator + "test.file", list[0]);
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 * Test listing files in a zip.
	 */
	public void testList() {

		try {
			String[] list = ZipUtilities.list(testZip);

			assertEquals(2, list.length);
			assertEquals("test/", list[0]);
			assertEquals("test/test.file", list[1]);
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}
}
