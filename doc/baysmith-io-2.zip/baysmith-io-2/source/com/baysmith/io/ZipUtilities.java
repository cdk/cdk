/*
 *  Copyright (C) 2000  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 *  Facilitates operations Zip files.
 */
public class ZipUtilities {

	/**
	 *  Returns the names of the files and directories contained in
	 *  the given zip file.
	 *
	 *  @param zipFile the zip file whose contents are listed
	 *  @return array of Strings containing the names
	 *
	 *  @throws IOException
	 */
	public static String[] list(File zipFile) throws IOException {

		ArrayList list = new ArrayList();
		ZipFile zip = new ZipFile(zipFile);
		Enumeration entries = zip.entries();

		while (entries.hasMoreElements()) {
			ZipEntry ze = (ZipEntry) entries.nextElement();

			list.add(ze.getName());
		}

		zip.close();

		return (String[]) list.toArray(new String[list.size()]);
	}

	/**
	 * Copies a file into a zip file.
	 *
	 * @param zos  the zip to which to add the output
	 * @param f  the file to be copied
	 *
	 *  @throws FileNotFoundException
	 *  @throws IOException
	 */
	public static void copyFileIntoZip(ZipOutputStream zos, File f)
			throws FileNotFoundException, IOException {

		FileInputStream fis1 = new FileInputStream(f);

		try {
			ZipEntry ze1 = new ZipEntry(f.getPath());

			try {
				zos.putNextEntry(ze1);

				byte[] buffer = new byte[1024];
				int len = fis1.read(buffer);

				while (len > 0) {
					zos.write(buffer, 0, len);

					len = fis1.read(buffer);
				}
			} finally {
				zos.closeEntry();
			}
		} finally {
			fis1.close();
		}
	}

	/**
	 *  Copies the next file from a zip file.
	 *
	 *  @param zis  the zip from which to read
	 *  @param dir  the parent directory for the file to be copied
	 *  @return false if next zip entry not available
	 *
	 *
	 *  @throws FileNotFoundException
	 *  @throws IOException if unable to make a directory or parent
	 *  directory, or a read or write error occurs
	 */
	public static boolean copyFileFromZip(ZipInputStream zis, File dir)
			throws FileNotFoundException, IOException {

		ZipEntry ze1 = zis.getNextEntry();

		if (ze1 == null) {
			return false;
		}

		if (ze1.isDirectory()) {
			File newDir = new File(dir, ze1.getName());

			if (!newDir.mkdir()) {
				throw new IOException("unable to make directory: "
									  + newDir.toString());
			}

			return true;
		}

		File outputFile = new File(dir, ze1.getName());

		if (!outputFile.getParentFile().exists()) {
			if (!outputFile.getParentFile().mkdirs()) {
				throw new IOException("unable to make parent directory: "
									  + outputFile.getParentFile()
										  .toString());
			}
		}

		FileOutputStream fos1 = new FileOutputStream(outputFile);

		try {
			byte[] buffer = new byte[1024];
			int len = zis.read(buffer, 0, 1024);

			while (len > 0) {
				fos1.write(buffer, 0, len);

				len = zis.read(buffer, 0, 1024);
			}
		} finally {
			fos1.close();
		}

		return true;
	}
}
