/*
 *  Copyright (C) 2001  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import java.io.*;
import java.util.*;

/**
 *  Class InputStreamWatcher
 *
 *
 *  @author Bradley A. Smith (bradley@baysmith.com)
 */
public class InputStreamWatcher implements Runnable {

	/**
	 *  Creates a InputStreamWatcher
	 *
	 *
	 *  @param in
	 */
	public InputStreamWatcher(InputStream in) {
		this(in, 2000);
	}

	/**
	 *  Creates a InputStreamWatcher
	 *
	 *
	 *  @param in
	 *  @param checkRate
	 */
	public InputStreamWatcher(InputStream in, int checkRate) {
		stream = new InputStreamReader(in);
		this.checkRate = checkRate;
		addOutputStream(System.out);
	}

	public void setAutoFlush(boolean on) {
		autoFlush = on;
	}

	/**
	 *  Sets the output list to just the given writer.
	 *
	 *  @param out
	 */
	public void setOutputWriter(Writer out) {
		output.clear();
		output.add(out);
	}

	/**
	 *  Adds an writer to the list to which the output will be written.
	 *
	 *  @param out the writer
	 */
	public void addOutputWriter(Writer out) {
		output.add(out);
	}

	/**
	 *  Sets the output list to just the given stream.
	 *
	 *  @param out
	 */
	public void setOutputStream(OutputStream out) {
		setOutputWriter(new OutputStreamWriter(out));
	}

	/**
	 *  Adds a stream to the list to which the output will be written.
	 *
	 *  @param out the stream
	 */
	public void addOutputStream(OutputStream out) {
		addOutputWriter(new OutputStreamWriter(out));
	}

	/**
	 *  Method start
	 *
	 */
	public void start() {

		watching = true;
		watchThread = new Thread(this);

		watchThread.start();
	}

	/**
	 *  Method stop
	 *
	 */
	public void stop() {

		// Stop watch thread
		watching = false;

		try {
			watchThread.join();
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}

		// Retrieve remaining data
		try {
			transferData();
			flushOutputs();
		} catch (IOException e) {
			writeError(e);
		}

		watchThread = null;
	}

	/**
	 *  Method run
	 *
	 */
	public void run() {

		while (watching) {
			try {
				if (stream.ready()) {
					transferData();
					if (autoFlush) {
						flushOutputs();
					}
				}

				Thread.currentThread().sleep(checkRate);
			} catch (InterruptedException e) {
			} catch (IOException e) {
				writeError(e);

				watching = false;
			}
		}
	}

	synchronized void writeError(Throwable e) {
		Iterator outIter = output.iterator();
		while(outIter.hasNext()) {
			Writer out = (Writer) outIter.next();
			PrintWriter error = new PrintWriter(out);
			error.println(e);
		}
	}


	/**
	 *  Method transferData
	 *
	 *
	 *  @throws IOException
	 */
	synchronized void transferData() throws IOException {

		char[] data = new char[1024];
		int n;

		synchronized (stream) {
			n = stream.read(data);
		}

		while (n > 0) {
			Iterator outIter = output.iterator();
			while(outIter.hasNext()) {
				Writer out = (Writer) outIter.next();
				synchronized (out) {
					out.write(data, 0, n);
				}
			}

			synchronized (stream) {
				n = stream.read(data);
			}
		}
	}

	synchronized void flushOutputs() throws IOException {
		Iterator outIter = output.iterator();
		while(outIter.hasNext()) {
			Writer out = (Writer) outIter.next();
			out.flush();
		}
	}


	/**
	 *  Field stream
	 */
	private InputStreamReader stream;

	/**
	 *  List of writers to which the output is written.
	 */
	private List output = new ArrayList();

	/**
	 *  Field checkRate
	 */
	private int checkRate;

	private boolean autoFlush = false;

	/**
	 *  Field watchThread
	 */
	private Thread watchThread = null;

	/**
	 *  Field watching
	 */
	private boolean watching;
}
