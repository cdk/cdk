/*
 *  Copyright (C) 2000  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import junit.framework.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import org.netbeans.lib.cvsclient.*;
import org.netbeans.lib.cvsclient.connection.*;
import org.netbeans.lib.cvsclient.admin.*;
import org.netbeans.lib.cvsclient.command.*;
import org.netbeans.lib.cvsclient.command.add.*;
import org.netbeans.lib.cvsclient.command.remove.*;
import org.netbeans.lib.cvsclient.event.*;
import org.netbeans.lib.cvsclient.commandLine.*;

/**
 * Tests for the CvsUtilities class.
 */
public class TestCvsUtilities extends junit.framework.TestCase {

	/**
	 *  Test directory for isolating testing operations.
	 */
	File testDirectory;

	/**
	 *  Method main
	 *
	 *
	 *  @param args
	 */
	public static void main(String[] args) {
		junit.textui.TestRunner.run(suite());
	}

	/**
	 * Create a test case with given name.
	 *
	 * @param name this test case's name.
	 */
	public TestCvsUtilities(String name) {
		super(name);
	}

	/**
	 * Setup fixtures.
	 */
	public void setUp() {

		setUpTestDirectory();

		// Extract example CVS project
		try {
			File testZip = new File("test.zip");

			FileUtilities
				.copyStreamToFile(getClass()
					.getResourceAsStream("TestCvsUtilities.zip"), testZip);

			ZipInputStream zis =
				new ZipInputStream(new FileInputStream(testZip));

			while (ZipUtilities.copyFileFromZip(zis, new File("."))) {

				// continue
			}			

			zis.close();
			assert(testZip.delete());

			File cvsroot = new File("cvsroot");
			
			PrintWriter output = new PrintWriter(new FileWriter("baysmith/CVS/Root"));
			output.println(cvsroot.getAbsolutePath());
			output.close();
			
			output = new PrintWriter(new FileWriter("baysmith/documentation/CVS/Root"));
			output.println(cvsroot.getAbsolutePath());
			output.close();

			FileUtilities.chdir("baysmith");

		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Method setUpTestDirectory
	 *
	 */
	void setUpTestDirectory() {

		try {
			testDirectory = new File(".", "TestCvsUtilities.directory");

			assert("Set up error: TestCvsUtilities.directory exists",
				   !testDirectory.exists());
			testDirectory.mkdir();
			FileUtilities.chdir("TestCvsUtilities.directory");
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Method tearDown
	 *
	 */
	public void tearDown() {

		try {
			FileUtilities.chdir("../..");
			assert(FileUtilities.deleteAll(testDirectory));
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 * Returns suite of tests contained in this test case.
	 *
	 *  @return all tests in this test case
	 */
	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(TestCvsUtilities.class);
	}

	/**
	 * Test isCvsFile method.
	 */
	public void testIsCvsFile() {
		assert(CvsUtilities.isCvsFile(new File("CVS")));
		assert(!CvsUtilities.isCvsFile(new File("documentation")));
	}

	/**
	 * Test isCvsControlled method.
	 */
	public void testIsCvsControlled() {

		assert(CvsUtilities.isCvsControlled(new File("documentation")));
		assert(CvsUtilities.isCvsControlled(new File(".", "build.xml")));
		assert(!CvsUtilities.isCvsControlled(new File("tmp")));
	}

	/**
	 *  Test getCvsDirectory method.
	 */
	public void testGetCvsDirectory() {

		File cvsDir = CvsUtilities.getCvsDirectory(new File("."));

		assert(cvsDir.exists());
		assertEquals("CVS", cvsDir.getName());

		String[] list = cvsDir.list();

		assertEquals(3, list.length);
		assertEquals("Repository", list[0]);
		assertEquals("Entries", list[1]);
		assertEquals("Root", list[2]);
	}

	/**
	 *  Test removing a file entry.
	 */
	public void testRemoveFile() {

		try {
			File workingDir = new File(System.getProperty("user.dir"));
			File removeFile = new File(workingDir, "build.xml");

			try {
				CvsUtilities.removeFile(removeFile);
				fail("exception expected");
			} catch (CommandException ex) {
				assertEquals("file 'build.xml' still exists",
							 ex.getMessage());
			}

			removeFile.delete();
			CvsUtilities.removeFile(removeFile);

			Client client =
				CvsUtilities
					.getClient(CvsUtilities.getCvsDirectory(workingDir));
			Iterator entries = client.getEntries(workingDir);

			assert(entries.hasNext());

			Entry e = (Entry) entries.next();

			assertEquals("documentation", e.getName());
			assert(e.isDirectory());

			e = (Entry) entries.next();

			assertEquals("build.xml", e.getName());
			assert(e.isUserFileToBeRemoved());
		} catch (CommandException ex) {
			ex.printStackTrace();
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Test adding a file entry.
	 */
	public void testAddFile() {

		try {
			File newFile = new File(System.getProperty("user.dir"),
									"manifest2");

			try {
				CvsUtilities.addFile(newFile);
				fail("exception expected");
			} catch (CommandException ex) {
				assertEquals("file 'manifest2' does not exist",
							 ex.getMessage());
			}

			PrintWriter manifestOutput =
				new PrintWriter(new FileWriter(newFile));

			manifestOutput.println("test add file to CVS");
			manifestOutput.close();
			CvsUtilities.addFile(newFile);

			File[] files = CvsUtilities.getFiles(newFile.getParentFile());

			assertEquals(5, files.length);
			assertEquals("build.xml", files[0].getName());
			assertEquals("index.html", files[1].getName());
			assertEquals("license", files[2].getName());
			assertEquals("manifest", files[3].getName());
			assertEquals("manifest2", files[4].getName());
		} catch (CommandException ex) {
			ex.printStackTrace();
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Test CVS via cvslib library.
	 */
	public void testCvslib() {

		try {
			File cvsRootFile = new File("CVS/Root");

			assert(cvsRootFile.exists());

			BufferedReader input =
				new BufferedReader(new FileReader(cvsRootFile));
			String cvsRoot = input.readLine();

			input.close();

			GlobalOptions options = new GlobalOptions();

			options.setCVSRoot(cvsRoot);

			ServerConnection connection = new ServerConnection();

			connection.setRepository(cvsRoot);
			connection.open();

			StandardAdminHandler admin = new StandardAdminHandler();
			Client client = new Client(connection, admin);

			client.setLocalPath(System.getProperty("user.dir"));

			Iterator i = client.getEntries(new File("."));

			assertEquals("D/documentation////", i.next().toString());
			assertEquals("/build.xml/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("/index.html/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("/license/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("/manifest/1.2/Thu Jan 25 17:27:53 2001//",
						 i.next().toString());
			assert(!i.hasNext());

			PrintWriter manifestOutput =
				new PrintWriter(new FileWriter("manifest2"));

			manifestOutput.println("test add file to CVS");
			manifestOutput.close();

			AddCommand addFile = new AddCommand();

			addFile.setFiles(new File[]{ new File(".", "manifest2") });
			client.executeCommand(addFile, options);

			i = client.getEntries(new File("."));

			assertEquals("D/documentation////", i.next().toString());
			assertEquals("/build.xml/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("/index.html/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("/license/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("/manifest/1.2/Thu Jan 25 17:27:53 2001//",
						 i.next().toString());
			assertEquals("/manifest2/0/dummy timestamp//",
						 i.next().toString());
			assert(!i.hasNext());
		} catch (CommandException ex) {
			ex.printStackTrace();
			fail(ex.toString());
		} catch (AuthenticationException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Test CVS via cvslib library.
	 */
	public void testCvslib2() {

		try {
			File cvsRootFile = new File("CVS/Root");

			assert(cvsRootFile.exists());

			BufferedReader input =
				new BufferedReader(new FileReader(cvsRootFile));
			String cvsRoot = input.readLine();

			input.close();

			GlobalOptions options = new GlobalOptions();

			options.setCVSRoot(cvsRoot);

			ServerConnection connection = new ServerConnection();

			connection.setRepository(cvsRoot);
			connection.open();

			StandardAdminHandler admin = new StandardAdminHandler();
			Client client = new Client(connection, admin);

			client.setLocalPath(System.getProperty("user.dir"));

			Iterator i = client.getEntries(new File("documentation"));

			assertEquals("before 1", "/ant.license/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assertEquals("before 2",
						 "/cvslib.license.html/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assert(!i.hasNext());

			File removeFile = new File("documentation", "ant.license");

			assert(removeFile.delete());

			RemoveCommand remove = new RemoveCommand();

			remove.setFiles(new File[]{ removeFile });
			client.executeCommand(remove, options);

			i = client.getEntries(new File("documentation"));

			assertEquals("after 1", "/ant.license/-1.1/dummy timestamp//",
						 i.next().toString());
			assertEquals("after 2", "/cvslib.license.html/1.1/Thu Jan 25 17:26:46 2001//",
						 i.next().toString());
			assert(!i.hasNext());
		} catch (CommandException ex) {
			ex.printStackTrace();
			fail(ex.toString());
		} catch (AuthenticationException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}
}
