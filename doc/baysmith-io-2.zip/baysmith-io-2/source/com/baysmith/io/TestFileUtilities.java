/*
 *  Copyright (C) 2000  Bradley A. Smith
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *  
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */
package com.baysmith.io;

import junit.framework.*;
import java.io.*;
import java.util.*;

/**
 * Tests for the FileUtilities class.
 */
public class TestFileUtilities extends TestCase {

	/**
	 *  Field testDirectory
	 */
	File testDirectory;

	/**
	 *  Method main
	 *
	 *
	 *  @param args
	 */
	public static void main(String[] args) {
		junit.textui.TestRunner.run(suite());
	}

	/**
	 * Create a test case with given name.
	 *
	 * @param name this test case's name.
	 */
	public TestFileUtilities(String name) {
		super(name);
	}

	/**
	 * Setup fixtures.
	 */
	public void setUp() {

		try {
			testDirectory = new File(".", "TestFileUtilities.directory");

			assert("Set up error: TestFileUtilities.directory exists",
				   !testDirectory.exists());
			testDirectory.mkdir();

			PrintWriter pw1 = new PrintWriter(
				new FileWriter("TestFileUtilities.directory/new.file"));

			pw1.println("Test file");
			pw1.close();
			FileUtilities.chdir("TestFileUtilities.directory");
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Method tearDown
	 *
	 */
	public void tearDown() {

		try {
			File[] files = (new File(".")).listFiles();

			while (files.length != 0) {
				for (int i = 0; i < files.length; ++i) {
					if (files[i].exists()) {
						assert(files[i].delete());
					}
				}

				files = (new File(".")).listFiles();
			}

			FileUtilities.chdir("..");
			assert(testDirectory.delete());
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 * Returns suite of tests contained in this test case.
	 *
	 *  @return
	 */
	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(TestFileUtilities.class);
	}

	/**
	 *  Test chdir method.
	 */
	public void testChdir() {

		File currentDir = new File(".");
		String path = currentDir.getAbsolutePath();

		assert(path.startsWith(System.getProperty("user.dir")));

		path = path.substring(0, path.length() - 2);
		path = path.substring(path.lastIndexOf(File.separator) + 1);

		assertEquals("TestFileUtilities.directory", path);

		try {
			FileUtilities.chdir("bogus.dir");
			fail("exception expected");
		} catch (FileNotFoundException ex) {
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Test getFileSet method.
	 */
	public void testGetFileSet() {

		Set fileSet = FileUtilities.getFileSet();

		assertEquals(1, fileSet.size());

		Iterator fileIter = fileSet.iterator();

		if (fileIter.hasNext()) {
			File file1 = (File) fileIter.next();

			assertEquals("new.file", file1.getName());
		}
	}

	/**
	 *  Test copyFile method.
	 */
	public void testCopyFile() {

		try {
			FileUtilities.copyFile(new File(".", "new.file"),
								   new File(".", "copy.file"));
		} catch (IOException ex) {
			fail(ex.toString());
		}

		BufferedReader input = null;
		BufferedReader referenceInput = null;

		try {
			input = new BufferedReader(new FileReader("copy.file"));
			referenceInput = new BufferedReader(new FileReader("new.file"));

			String line = input.readLine();
			String referenceLine = referenceInput.readLine();
			int lineNumber = 1;

			while ((line != null) && (referenceLine != null)) {
				if (!line.equals(referenceLine)) {
					fail("output different at line " + lineNumber);
				}

				line = input.readLine();
				referenceLine = referenceInput.readLine();

				++lineNumber;
			}

			if (!((line == null) && (referenceLine == null))) {
				fail("output different at line " + lineNumber);
			}
		} catch (IOException ex) {
			fail(ex.toString());
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException ex) {
					fail(ex.toString());
				}
			}

			if (referenceInput != null) {
				try {
					referenceInput.close();
				} catch (IOException ex) {
					fail(ex.toString());
				}
			}
		}
	}

	/**
	 *  Test compareFile method.
	 */
	public void testCompareFiles() {

		try {
			FileUtilities.copyFile(new File(".", "new.file"),
								   new File(".", "copy.file"));
			assert(FileUtilities.compareFiles(new File(".", "new.file"),
											  new File(".", "copy.file")));
		} catch (IOException ex) {
			fail(ex.toString());
		}
	}

	/**
	 *  Test deleteAll method.
	 */
	public void testDeleteAll() {

		Set fileSet = FileUtilities.getFileSet();

		assertEquals(1, fileSet.size());
		assert(FileUtilities.deleteAll((new File(".")).listFiles(), true));

		fileSet = FileUtilities.getFileSet();

		assertEquals(0, fileSet.size());
	}

	/**
	 *  Test other deleteAll method.
	 */
	public void testDeleteAll2() {

		File dir = new File(".", "deleteAll2");

		try {
			dir.mkdir();

			PrintWriter pw1 =
				new PrintWriter(new FileWriter("deleteAll2/delete.me"));

			pw1.println("Test file");
			pw1.close();
		} catch (FileNotFoundException ex) {
			fail(ex.toString());
		} catch (IOException ex) {
			fail(ex.toString());
		}

		assertEquals(1, dir.listFiles().length);
		assert(FileUtilities.deleteAll(dir));
		assert(!dir.exists());
	}

	/**
	 *  Test deleteAll method when permission to delete is denied.
	 */
	public void testDeleteAll3() {

		File dir = new File("/tmp");

		assert(dir.exists());
		assert(dir.isDirectory());
		assert(!FileUtilities.deleteAll(dir));
		assert(dir.exists());
	}
}
