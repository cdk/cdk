(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BufferedImageOp");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-12 08:27:28 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
