(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'io.github.dan2097.jnainchi.inchi.tagNormAtomData','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagINCHIGEN_DATA", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.pStrErrStruct=Clazz.array(Byte.TYPE, [256]);
this.num_components=Clazz.array(Integer.TYPE, [2]);
this.NormAtomsNontaut=Clazz.array($I$(1), [2]);
this.NormAtomsTaut=Clazz.array($I$(1), [2]);
},1);

C$.$fields$=[['O',['pStrErrStruct','byte[]','num_components','int[]','NormAtomsNontaut','io.github.dan2097.jnainchi.inchi.tagNormAtomData[]','+NormAtomsTaut']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(2,"asList$OA",[Clazz.array(String, -1, ["pStrErrStruct", "num_components", "NormAtomsNontaut", "NormAtomsTaut"])]);
});

Clazz.newMeth(C$, 'c$$BA$IA$io_github_dan2097_jnainchi_inchi_tagNormAtomDataA$io_github_dan2097_jnainchi_inchi_tagNormAtomDataA',  function (pStrErrStruct, num_components, NormAtomsNontaut, NormAtomsTaut) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
if ((pStrErrStruct.length != this.pStrErrStruct.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.pStrErrStruct=pStrErrStruct;
if ((num_components.length != this.num_components.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.num_components=num_components;
if ((NormAtomsNontaut.length != this.NormAtomsNontaut.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.NormAtomsNontaut=NormAtomsNontaut;
if ((NormAtomsTaut.length != this.NormAtomsTaut.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.NormAtomsTaut=NormAtomsTaut;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-24 20:58:34 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
