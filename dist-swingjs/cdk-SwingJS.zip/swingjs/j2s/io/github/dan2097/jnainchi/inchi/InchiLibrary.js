(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'com.sun.jna.NativeLibrary','com.sun.jna.Native']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiLibrary", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'com.sun.jna.Library');
C$.$classes$=[['tagINCHIRadical',9],['tagINCHIBondType',9],['tagINCHIBondStereo2D',9],['tagINCHIStereoType0D',9],['tagINCHIStereoParity0D',9],['tagRetValGetINCHI',9],['tagRetValMOL2INCHI',9],['tagRetValCheckINCHI',9],['tagRetValGetINCHIKey',9],['IXA_STATUS',9],['IXA_ATOM_RADICAL',9],['IXA_BOND_TYPE',9],['IXA_BOND_WEDGE',9],['IXA_DBLBOND_CONFIG',9],['IXA_STEREO_TOPOLOGY',9],['IXA_STEREO_PARITY',9],['IXA_INCHIBUILDER_OPTION',9],['IXA_INCHIBUILDER_STEREOOPTION',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['JNA_NATIVE_LIB','com.sun.jna.NativeLibrary']]]

Clazz.newMeth(C$, 'GetINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_Input$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (inp, out) {
alert('native method must be replaced! GetINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetStdINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_Input$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (inp, out) {
alert('native method must be replaced! GetStdINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetINCHIEx$io_github_dan2097_jnainchi_inchi_inchi_InputEx$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (inp, out) {
alert('native method must be replaced! GetINCHIEx');
}
, 2);

Clazz.newMeth(C$, 'FreeINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (out) {
alert('native method must be replaced! FreeINCHI');
}
, 2);

Clazz.newMeth(C$, 'FreeStdINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (out) {
alert('native method must be replaced! FreeStdINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetStructFromINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_InputINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStruct',  function (inpInChI, outStruct) {
alert('native method must be replaced! GetStructFromINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetStructFromStdINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_InputINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStruct',  function (inpInChI, outStruct) {
alert('native method must be replaced! GetStructFromStdINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetStructFromINCHIEx$io_github_dan2097_jnainchi_inchi_tagINCHI_InputINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStructEx',  function (inpInChI, outStruct) {
alert('native method must be replaced! GetStructFromINCHIEx');
}
, 2);

Clazz.newMeth(C$, 'FreeStructFromINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStruct',  function (out) {
alert('native method must be replaced! FreeStructFromINCHI');
}
, 2);

Clazz.newMeth(C$, 'FreeStructFromStdINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStruct',  function (out) {
alert('native method must be replaced! FreeStructFromStdINCHI');
}
, 2);

Clazz.newMeth(C$, 'FreeStructFromINCHIEx$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStructEx',  function (out) {
alert('native method must be replaced! FreeStructFromINCHIEx');
}
, 2);

Clazz.newMeth(C$, 'GetINCHIfromINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_InputINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (inpInChI, out) {
alert('native method must be replaced! GetINCHIfromINCHI');
}
, 2);

Clazz.newMeth(C$, 'Get_inchi_Input_FromAuxInfo$S$Z$Z$io_github_dan2097_jnainchi_inchi_tagInchiInpData',  function (szInchiAuxInfo, bDoNotAddH, bDiffUnkUndfStereo, pInchiInp) {
alert('native method must be replaced! Get_inchi_Input_FromAuxInfo');
}
, 2);

Clazz.newMeth(C$, 'Get_std_inchi_Input_FromAuxInfo$S$Z$io_github_dan2097_jnainchi_inchi_tagInchiInpData',  function (szInchiAuxInfo, bDoNotAddH, pInchiInp) {
alert('native method must be replaced! Get_std_inchi_Input_FromAuxInfo');
}
, 2);

Clazz.newMeth(C$, 'Free_inchi_Input$io_github_dan2097_jnainchi_inchi_tagINCHI_Input',  function (pInp) {
alert('native method must be replaced! Free_inchi_Input');
}
, 2);

Clazz.newMeth(C$, 'Free_std_inchi_Input$io_github_dan2097_jnainchi_inchi_tagINCHI_Input',  function (pInp) {
alert('native method must be replaced! Free_std_inchi_Input');
}
, 2);

Clazz.newMeth(C$, 'CheckINCHI$S$Z',  function (szINCHI, strict) {
alert('native method must be replaced! CheckINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetINCHIKeyFromINCHI$S$I$I$BA$BA$BA',  function (szINCHISource, xtra1, xtra2, szINCHIKey, szXtra1, szXtra2) {
alert('native method must be replaced! GetINCHIKeyFromINCHI');
}
, 2);

Clazz.newMeth(C$, 'GetStdINCHIKeyFromStdINCHI$S$java_nio_ByteBuffer',  function (szINCHISource, szINCHIKey) {
alert('native method must be replaced! GetStdINCHIKeyFromStdINCHI');
}
, 2);

Clazz.newMeth(C$, 'CheckINCHIKey$S',  function (szINCHIKey) {
alert('native method must be replaced! CheckINCHIKey');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_Create$',  function () {
alert('native method must be replaced! INCHIGEN_Create');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_Create$',  function () {
alert('native method must be replaced! STDINCHIGEN_Create');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_Setup$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA$io_github_dan2097_jnainchi_inchi_tagINCHI_Input',  function (HGen, pGenData, pInp) {
alert('native method must be replaced! INCHIGEN_Setup');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_Setup$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA$io_github_dan2097_jnainchi_inchi_tagINCHI_Input',  function (HGen, pGenData, pInp) {
alert('native method must be replaced! STDINCHIGEN_Setup');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_DoNormalization$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA',  function (HGen, pGenData) {
alert('native method must be replaced! INCHIGEN_DoNormalization');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_DoNormalization$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA',  function (HGen, pGenData) {
alert('native method must be replaced! STDINCHIGEN_DoNormalization');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_DoCanonicalization$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA',  function (HGen, pGenData) {
alert('native method must be replaced! INCHIGEN_DoCanonicalization');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_DoCanonicalization$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA',  function (HGen, pGenData) {
alert('native method must be replaced! STDINCHIGEN_DoCanonicalization');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_DoSerialization$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (HGen, pGenData, pResults) {
alert('native method must be replaced! INCHIGEN_DoSerialization');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_DoSerialization$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (HGen, pGenData, pResults) {
alert('native method must be replaced! STDINCHIGEN_DoSerialization');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_Reset$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (HGen, pGenData, pResults) {
alert('native method must be replaced! INCHIGEN_Reset');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_Reset$com_sun_jna_Pointer$io_github_dan2097_jnainchi_inchi_tagINCHIGEN_DATA$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (HGen, pGenData, pResults) {
alert('native method must be replaced! STDINCHIGEN_Reset');
}
, 2);

Clazz.newMeth(C$, 'INCHIGEN_Destroy$com_sun_jna_Pointer',  function (HGen) {
alert('native method must be replaced! INCHIGEN_Destroy');
}
, 2);

Clazz.newMeth(C$, 'STDINCHIGEN_Destroy$com_sun_jna_Pointer',  function (HGen) {
alert('native method must be replaced! STDINCHIGEN_Destroy');
}
, 2);

Clazz.newMeth(C$, 'MakeINCHIFromMolfileText$S$S$io_github_dan2097_jnainchi_inchi_tagINCHI_Output',  function (moltext, options, result) {
alert('native method must be replaced! MakeINCHIFromMolfileText');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_Create$',  function () {
alert('native method must be replaced! IXA_STATUS_Create');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_Clear$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_STATUS_Clear');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_Destroy$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_STATUS_Destroy');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_HasError$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_STATUS_HasError');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_HasWarning$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_STATUS_HasWarning');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_GetCount$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_STATUS_GetCount');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_GetSeverity$com_sun_jna_Pointer$I',  function (hStatus, vIndex) {
alert('native method must be replaced! IXA_STATUS_GetSeverity');
}
, 2);

Clazz.newMeth(C$, 'IXA_STATUS_GetMessage$com_sun_jna_Pointer$I',  function (hStatus, vIndex) {
alert('native method must be replaced! IXA_STATUS_GetMessage');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_Create$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_MOL_Create');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_Clear$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_Clear');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_Destroy');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_ReadMolfile$com_sun_jna_Pointer$com_sun_jna_Pointer$BA',  function (hStatus, hMolecule, pBytes) {
alert('native method must be replaced! IXA_MOL_ReadMolfile');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_ReadInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$BA',  function (hStatus, hMolecule, pInChI) {
alert('native method must be replaced! IXA_MOL_ReadInChI');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer$Z',  function (hStatus, hMolecule, vChiral) {
alert('native method must be replaced! IXA_MOL_SetChiral');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_GetChiral');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_CreateAtom$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_CreateAtom');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$BA',  function (hStatus, hMolecule, vAtom, pElement) {
alert('native method must be replaced! IXA_MOL_SetAtomElement');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vAtomicNumber) {
alert('native method must be replaced! IXA_MOL_SetAtomAtomicNumber');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vMassNumber) {
alert('native method must be replaced! IXA_MOL_SetAtomMass');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vCharge) {
alert('native method must be replaced! IXA_MOL_SetAtomCharge');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vRadical) {
alert('native method must be replaced! IXA_MOL_SetAtomRadical');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I',  function (hStatus, hMolecule, vAtom, vHydrogenMassNumber, vHydrogenCount) {
alert('native method must be replaced! IXA_MOL_SetAtomHydrogens');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D',  function (hStatus, hMolecule, vAtom, vX) {
alert('native method must be replaced! IXA_MOL_SetAtomX');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D',  function (hStatus, hMolecule, vAtom, vY) {
alert('native method must be replaced! IXA_MOL_SetAtomY');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D',  function (hStatus, hMolecule, vAtom, vZ) {
alert('native method must be replaced! IXA_MOL_SetAtomZ');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_CreateBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom1, vAtom2) {
alert('native method must be replaced! IXA_MOL_CreateBond');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBond, vType) {
alert('native method must be replaced! IXA_MOL_SetBondType');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBond, vRefAtom, vDirection) {
alert('native method must be replaced! IXA_MOL_SetBondWedge');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBond, vConfig) {
alert('native method must be replaced! IXA_MOL_SetDblBondConfig');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoTetrahedron$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4) {
alert('native method must be replaced! IXA_MOL_CreateStereoTetrahedron');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vCentralBond, vVertex1, vVertex2, vVertex3, vVertex4) {
alert('native method must be replaced! IXA_MOL_CreateStereoRectangle');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoAntiRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4) {
alert('native method must be replaced! IXA_MOL_CreateStereoAntiRectangle');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_SetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vStereo, vParity) {
alert('native method must be replaced! IXA_MOL_SetStereoParity');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_ReserveSpace$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I$I',  function (hStatus, hMolecule, num_atoms, num_bonds, num_stereos) {
alert('native method must be replaced! IXA_MOL_ReserveSpace');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetNumAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_GetNumAtoms');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_GetNumBonds');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomId$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtomIndex) {
alert('native method must be replaced! IXA_MOL_GetAtomId');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondId$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBondIndex) {
alert('native method must be replaced! IXA_MOL_GetBondId');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomIndex');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
alert('native method must be replaced! IXA_MOL_GetBondIndex');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomNumBonds');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vBondIndex) {
alert('native method must be replaced! IXA_MOL_GetAtomBond');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetCommonBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom1, vAtom2) {
alert('native method must be replaced! IXA_MOL_GetCommonBond');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondAtom1$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
alert('native method must be replaced! IXA_MOL_GetBondAtom1');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondAtom2$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
alert('native method must be replaced! IXA_MOL_GetBondAtom2');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondOtherAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond, vAtom) {
alert('native method must be replaced! IXA_MOL_GetBondOtherAtom');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomElement');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomAtomicNumber');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomMass');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomCharge');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomRadical');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vHydrogenMassNumber) {
alert('native method must be replaced! IXA_MOL_GetAtomHydrogens');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomX');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomY');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
alert('native method must be replaced! IXA_MOL_GetAtomZ');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
alert('native method must be replaced! IXA_MOL_GetBondType');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond, vRefAtom) {
alert('native method must be replaced! IXA_MOL_GetBondWedge');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
alert('native method must be replaced! IXA_MOL_GetDblBondConfig');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetNumStereos$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
alert('native method must be replaced! IXA_MOL_GetNumStereos');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoId$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vStereoIndex) {
alert('native method must be replaced! IXA_MOL_GetStereoId');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
alert('native method must be replaced! IXA_MOL_GetStereoIndex');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoTopology$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
alert('native method must be replaced! IXA_MOL_GetStereoTopology');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoCentralAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
alert('native method must be replaced! IXA_MOL_GetStereoCentralAtom');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoCentralBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
alert('native method must be replaced! IXA_MOL_GetStereoCentralBond');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoNumVertices$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
alert('native method must be replaced! IXA_MOL_GetStereoNumVertices');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoVertex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vStereo, vVertexIndex) {
alert('native method must be replaced! IXA_MOL_GetStereoVertex');
}
, 2);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
alert('native method must be replaced! IXA_MOL_GetStereoParity');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_Create$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_INCHIBUILDER_Create');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetMolecule$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder, hMolecule) {
alert('native method must be replaced! IXA_INCHIBUILDER_SetMolecule');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
alert('native method must be replaced! IXA_INCHIBUILDER_GetInChI');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetInChIEx$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hBuilder) {
alert('native method must be replaced! IXA_INCHIBUILDER_GetInChIEx');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetAuxInfo$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
alert('native method must be replaced! IXA_INCHIBUILDER_GetAuxInfo');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetLog$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
alert('native method must be replaced! IXA_INCHIBUILDER_GetLog');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
alert('native method must be replaced! IXA_INCHIBUILDER_Destroy');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z',  function (hStatus, hInChIBuilder, vOption, vValue) {
alert('native method must be replaced! IXA_INCHIBUILDER_SetOption');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vValue) {
alert('native method must be replaced! IXA_INCHIBUILDER_SetOption_Stereo');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Timeout$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vValue) {
alert('native method must be replaced! IXA_INCHIBUILDER_SetOption_Timeout');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$com_sun_jna_Pointer$com_sun_jna_Pointer$J',  function (hStatus, hInChIBuilder, vValue) {
alert('native method must be replaced! IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_CheckOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vOption) {
alert('native method must be replaced! IXA_INCHIBUILDER_CheckOption');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_CheckOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vValue) {
alert('native method must be replaced! IXA_INCHIBUILDER_CheckOption_Stereo');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_Create$com_sun_jna_Pointer',  function (hStatus) {
alert('native method must be replaced! IXA_INCHIKEYBUILDER_Create');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_SetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$BA',  function (hStatus, hInChIKeyBuilder, pInChI) {
alert('native method must be replaced! IXA_INCHIKEYBUILDER_SetInChI');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_GetInChIKey$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIKeyBuilder) {
alert('native method must be replaced! IXA_INCHIKEYBUILDER_GetInChIKey');
}
, 2);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIKeyBuilder) {
alert('native method must be replaced! IXA_INCHIKEYBUILDER_Destroy');
}
, 2);

C$.$static$=function(){C$.$static$=0;
C$.JNA_NATIVE_LIB=$I$(1).getInstance$S("jnainchi");
{
$I$(2,"register$Class$com_sun_jna_NativeLibrary",[Clazz.getClass(C$), C$.JNA_NATIVE_LIB]);
};
};
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagINCHIRadical", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagINCHIBondType", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagINCHIBondStereo2D", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagINCHIStereoType0D", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagINCHIStereoParity0D", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagRetValGetINCHI", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagRetValMOL2INCHI", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagRetValCheckINCHI", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "tagRetValGetINCHIKey", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_STATUS", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_ATOM_RADICAL", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_BOND_TYPE", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_BOND_WEDGE", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_DBLBOND_CONFIG", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_STEREO_TOPOLOGY", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_STEREO_PARITY", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_INCHIBUILDER_OPTION", function(){
});
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.InchiLibrary, "IXA_INCHIBUILDER_STEREOOPTION", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-24 20:58:34 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
