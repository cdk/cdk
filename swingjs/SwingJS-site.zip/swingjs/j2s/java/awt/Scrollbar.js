(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Scrollbar", null, 'swingjs.a2s.Scrollbar');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (orientation) {
;C$.superclazz.c$$I.apply(this,[orientation]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I',  function (orientation, value, visible, minimum, maximum) {
;C$.superclazz.c$$I$I$I$I$I.apply(this,[orientation, value, visible, minimum, maximum]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-12 08:27:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
